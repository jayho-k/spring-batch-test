package com.example.Partition_Test.ChunkTest.delegate;

public enum DelegateEnum {

    EVEN_ODD

}
