package com.example.Partition_Test.ChunkTest.config;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Getter
@Setter
public class MapConfig {
    private volatile String MapPath;

}
