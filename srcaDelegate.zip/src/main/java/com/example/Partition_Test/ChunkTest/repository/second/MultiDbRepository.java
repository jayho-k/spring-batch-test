package com.example.Partition_Test.ChunkTest.repository.second;


import com.example.Partition_Test.ChunkTest.entity.second.MultiDb;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MultiDbRepository extends JpaRepository<MultiDb, Long> {
}
