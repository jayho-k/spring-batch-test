package com.example.Partition_Test.ChunkTest;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.batch.item.Chunk;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AgvSum extends Chunk<AgvSum> {

    @Id
    private int id;
    private int sum;

}
