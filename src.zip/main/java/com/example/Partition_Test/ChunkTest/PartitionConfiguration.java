package com.example.Partition_Test.ChunkTest;


import lombok.RequiredArgsConstructor;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.core.step.item.ChunkOrientedTasklet;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.database.*;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.database.support.MySqlPagingQueryProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;
import java.util.HashMap;

@Configuration
@RequiredArgsConstructor
public class PartitionConfiguration {

    private final DataSource dataSource;
    private final int chunkSize = 10;

    @Bean
    public Job partitionJob(JobRepository jobRepository, Step step){
        return new JobBuilder("partitionJob", jobRepository)
                .start(step)
                .build();
    }

    @Bean
    public Step step(JobRepository jobRepository, PlatformTransactionManager platformTransactionManager) throws Exception {
        return new StepBuilder("step", jobRepository)
                .<Agv, Agv>chunk(chunkSize, platformTransactionManager)
                .reader(itemReader())
                .writer(customItemWriter())
                .build();
    }

    @Bean
    public ItemReader<Agv> itemReader() throws Exception {

        JdbcPagingItemReader<Agv> reader = new JdbcPagingItemReader<>();

        reader.setDataSource(dataSource);
        reader.setPageSize(chunkSize);
        reader.setRowMapper(new BeanPropertyRowMapper(Agv.class));

        MySqlPagingQueryProvider queryProvider = new MySqlPagingQueryProvider();
        queryProvider.setSelectClause("id, time, even");
        queryProvider.setFromClause("from agv");

        HashMap<String, Order> sortKeys = new HashMap<>(1);
        sortKeys.put("id", Order.ASCENDING);
        queryProvider.setSortKeys(sortKeys);

        reader.setQueryProvider(queryProvider);
        reader.afterPropertiesSet();

        return reader;
    }


    @Bean
    @StepScope
    public CustomItemWriter<Agv> customItemWriter(){

        String sql = "insert into agvsum (id, sum) values (:id, :sum)";

        CustomItemWriter<Agv> agvCustomItemWriter = new CustomItemWriter<>();
        agvCustomItemWriter.setDataSource(dataSource);
        agvCustomItemWriter.setSql(sql);
        agvCustomItemWriter.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>());

        return agvCustomItemWriter;
    }







}
