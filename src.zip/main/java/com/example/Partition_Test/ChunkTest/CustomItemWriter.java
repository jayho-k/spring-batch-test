package com.example.Partition_Test.ChunkTest;

import lombok.RequiredArgsConstructor;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.Chunk;

import org.springframework.batch.item.ItemStream;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;


public class CustomItemWriter<T> extends JdbcBatchItemWriter<T> {

    @Override
    public void write(Chunk<? extends T> chunk) throws Exception {

        Chunk<AgvSum> agvSumChunk = new Chunk<>();

        int sum = 0;
        for (T t : chunk.getItems()){
            Agv agv = (Agv) t;
            sum ++;
            if (agv.getTime() %2 == 1){
                AgvSum agvSum = new AgvSum();
                agvSum.setId(agv.getTime());
                agvSum.setSum(sum);
                agvSumChunk.add(agvSum);
            }
        }

        super.write((Chunk<? extends T>) agvSumChunk);
    }

}


/*
    ExecutionContext stepContext = this.stepExecution.getExecutionContext();
    Map<String, Object> stringObjectMap = stepContext.toMap();




        for( String strKey : stringObjectMap.keySet() ){
                Object strValue = stringObjectMap.get(strKey);
                System.out.println( strKey +":"+ strValue );
                }
*/
