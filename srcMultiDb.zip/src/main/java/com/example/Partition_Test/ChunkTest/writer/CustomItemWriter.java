package com.example.Partition_Test.ChunkTest.writer;


import com.example.Partition_Test.ChunkTest.dto.AgvAgvSumDto;
import com.example.Partition_Test.ChunkTest.dto.AgvSumDto;
import com.example.Partition_Test.ChunkTest.entity.first.Agv;
import com.example.Partition_Test.ChunkTest.entity.second.MultiDb;
import com.example.Partition_Test.ChunkTest.repository.first.AgvRepository;
import com.example.Partition_Test.ChunkTest.repository.second.MultiDbRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.batch.item.Chunk;


import org.springframework.batch.item.database.JdbcBatchItemWriter;


import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;


@RequiredArgsConstructor
public class CustomItemWriter<T> extends JdbcBatchItemWriter<T> {

    private final boolean isEven;

    private final AgvRepository agvRepository;
    private final MultiDbRepository multiDbRepository;

    Queue<Agv> q = new LinkedList<>();

    @Override
    public void write(Chunk<? extends T> chunk) throws Exception {

        Chunk<AgvSumDto> agvSumChunk = new Chunk<>();

        List<Integer> times = new ArrayList<>();

        times.add(1);
        times.add(2);
        times.add(4);
        times.add(7);
        times.add(8);
        times.add(9);

        List<AgvAgvSumDto> agvAndSum = agvRepository.findAgvAndSum(times);
        for(AgvAgvSumDto agv : agvAndSum){
            System.out.println("agv time : " + agv.getTime());
        }

        MultiDb multiDb = new MultiDb();
        multiDb.setMultidb(3);
        multiDbRepository.save(multiDb);

        int sum = 0;
        if (isEven){
            for (T t : chunk.getItems()){
                Agv agv = (Agv) t;
                sum ++;
                if (agv.getTime() %2 == 0){
                    AgvSumDto agvSumDto = new AgvSumDto();
                    agvSumDto.setSum(sum);
                    agvSumDto.setAgvId(agv.getId());
                    agvSumChunk.add(agvSumDto);
                    //System.out.println("is even : " + agv.getTime());
                }
            }
        }
        else{
            for (T t : chunk.getItems()){
                Agv agv = (Agv) t;
                sum ++;
                if (agv.getTime() %2 == 1){
                    AgvSumDto agvSumDto = new AgvSumDto();
                    agvSumDto.setSum(sum);
                    agvSumDto.setAgvId(agv.getId());
                    agvSumChunk.add(agvSumDto);
                    //System.out.println("is not even : " + agv.getTime());
                }
            }
        }



        System.out.println(q.size());

        super.write((Chunk<? extends T>) agvSumChunk);
    }


/*    @Override
    public void write(Chunk<? extends T> chunk) throws Exception {

        Chunk<AgvSum> agvSumChunk = new Chunk<>();

        int sum = 0;
        for (T t : chunk.getItems()){
            Agv agv = (Agv) t;
            sum ++;
            if (agv.getTime() %2 == 1){

                AgvSum agvSum = new AgvSum();
                agvSum.setSum(sum);
                agvSumChunk.add(agvSum);

*//*                if (!q.isEmpty() && q.size() % 2 == 1){

                    AgvSum agvSum2 = new AgvSum();

                    Agv agvQ = q.poll();
                    System.out.println("@@@ agvQ.getTime : " + agvQ.getTime() + "sum : " + sum);

                    agvSum2.setSum(sum);
                    agvSumChunk.add(agvSum2);
                }*//*
            }
            else{
                q.add(agv);
            }
        }

        System.out.println(q.size());

        super.write((Chunk<? extends T>) agvSumChunk);
    }*/

}
