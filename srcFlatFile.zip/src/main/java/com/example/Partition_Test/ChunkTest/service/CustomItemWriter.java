package com.example.Partition_Test.ChunkTest.service;


import com.example.Partition_Test.ChunkTest.Entity.Agv;
import com.example.Partition_Test.ChunkTest.Entity.AgvSum;
import org.springframework.batch.item.Chunk;


import org.springframework.batch.item.database.JdbcBatchItemWriter;


import java.util.LinkedList;
import java.util.Queue;


public class CustomItemWriter<T> extends JdbcBatchItemWriter<T> {

    private boolean isEven;

    public CustomItemWriter(boolean isEven){
        this.isEven = isEven;
    }

    Queue<Agv> q = new LinkedList<>();
    @Override
    public void write(Chunk<? extends T> chunk) throws Exception {

        Chunk<AgvSum> agvSumChunk = new Chunk<>();

        int sum = 0;
        if (isEven){
            for (T t : chunk.getItems()){
                Agv agv = (Agv) t;
                sum ++;
                if (agv.getTime() %2 == 0){
                    Thread.sleep(100);
                    AgvSum agvSum = new AgvSum();
                    agvSum.setSum(sum);
                    agvSumChunk.add(agvSum);
                    System.out.println("is even : " + agv.getTime());
                }
            }
        }
        else{
            for (T t : chunk.getItems()){
                Agv agv = (Agv) t;
                sum ++;
                if (agv.getTime() %2 == 1){
                    AgvSum agvSum = new AgvSum();
                    agvSum.setSum(sum);
                    agvSumChunk.add(agvSum);
                    System.out.println("is not even : " + agv.getTime());
                }
            }
        }



        System.out.println(q.size());

        super.write((Chunk<? extends T>) agvSumChunk);
    }


/*    @Override
    public void write(Chunk<? extends T> chunk) throws Exception {

        Chunk<AgvSum> agvSumChunk = new Chunk<>();

        int sum = 0;
        for (T t : chunk.getItems()){
            Agv agv = (Agv) t;
            sum ++;
            if (agv.getTime() %2 == 1){

                AgvSum agvSum = new AgvSum();
                agvSum.setSum(sum);
                agvSumChunk.add(agvSum);

*//*                if (!q.isEmpty() && q.size() % 2 == 1){

                    AgvSum agvSum2 = new AgvSum();

                    Agv agvQ = q.poll();
                    System.out.println("@@@ agvQ.getTime : " + agvQ.getTime() + "sum : " + sum);

                    agvSum2.setSum(sum);
                    agvSumChunk.add(agvSum2);
                }*//*
            }
            else{
                q.add(agv);
            }
        }

        System.out.println(q.size());

        super.write((Chunk<? extends T>) agvSumChunk);
    }*/

}
